package es.almassora.reservas;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bot de reserva automática - Almassora SEM (i2ACRONOS), versión Android.
 *
 * Es la misma lógica que el programa de Python, pero en lugar de Playwright
 * usa el navegador integrado de Android (WebView). La app tiene que estar
 * ABIERTA y en pantalla para funcionar (la pantalla no se apaga sola
 * mientras el bot está activo).
 */
public class MainActivity extends Activity {

    // ─────────────────────────────────────────────────────────────
    //  CONFIGURACIÓN (equivalente a las constantes del .py)
    // ─────────────────────────────────────────────────────────────
    static final String BASE_URL = "https://almassora.i2a.es/CronosWeb/Login";

    static final int DIAS_ANTES = 3;          // la reserva abre 3 días...
    static final int HORAS_ANTES = 1;         // ...y 1 hora antes de la clase
    static final int ANTELACION_LOGIN = 120;  // segundos antes de la apertura en que se prepara
    static final int ESPERA_RAPIDA = 2;       // segundos entre intentos justo tras la apertura
    static final int DURACION_RAPIDA = 180;   // durante cuántos segundos se usa ESPERA_RAPIDA
    static final int ESPERA_REINTENTO = 10;   // segundos entre intentos el resto del tiempo
    static final int ERRORES_PARA_RELOGIN = 5;
    static final int DIAS_FECHAS = 28;        // días ofrecidos en el desplegable de fecha
    static final int MAX_LINEAS_LOG = 400;

    static final String[] DIAS_SEMANA = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
    static final String[] DIAS_CORTOS = {"Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"};
    static final String[] MESES = {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio",
            "agosto", "septiembre", "octubre", "noviembre", "diciembre"};
    static final String CADA_SEMANA = "Cada semana";
    static final String SIN_VALOR = "—";

    static final String INLINE = "#ContentFixedSection_uAltaEventos_uAltaEventosFechas_datetimepicker";

    static final String HORARIOS_DEFECTO = "{\"Aquagym\":{\"Lunes\":[\"10:20\",\"15:15\"],\"Martes\":[\"20:20\"],\"Miércoles\":[\"10:20\",\"15:15\"],\"Jueves\":[\"09:25\",\"11:15\",\"20:20\"],\"Viernes\":[\"09:15\",\"10:10\"],\"Sábado\":[],\"Domingo\":[]},\"Aerotonic\":{\"Lunes\":[\"19:00\"],\"Martes\":[],\"Miércoles\":[\"15:30\"],\"Jueves\":[],\"Viernes\":[],\"Sábado\":[],\"Domingo\":[]},\"Bodyfit\":{\"Lunes\":[\"16:30\"],\"Martes\":[\"15:30\",\"17:30\"],\"Miércoles\":[\"16:30\"],\"Jueves\":[\"17:30\"],\"Viernes\":[\"17:30\"],\"Sábado\":[],\"Domingo\":[]},\"Pilates\":{\"Lunes\":[\"08:00\",\"17:30\"],\"Martes\":[\"19:00\",\"20:15\"],\"Miércoles\":[\"08:00\"],\"Jueves\":[\"08:30\",\"16:30\",\"19:00\",\"20:15\"],\"Viernes\":[\"08:00\",\"16:30\"],\"Sábado\":[],\"Domingo\":[]},\"Zumbasem\":{\"Lunes\":[\"15:30\"],\"Martes\":[],\"Miércoles\":[\"19:00\"],\"Jueves\":[],\"Viernes\":[],\"Sábado\":[],\"Domingo\":[]},\"Ritmos Latinos\":{\"Lunes\":[],\"Martes\":[\"16:30\"],\"Miércoles\":[],\"Jueves\":[],\"Viernes\":[\"15:30\"],\"Sábado\":[],\"Domingo\":[]},\"Aerostep\":{\"Lunes\":[],\"Martes\":[],\"Miércoles\":[\"17:30\"],\"Jueves\":[\"15:30\"],\"Viernes\":[],\"Sábado\":[],\"Domingo\":[]},\"Aquathlon\":{\"Lunes\":[],\"Martes\":[],\"Miércoles\":[],\"Jueves\":[\"06:50\"],\"Viernes\":[],\"Sábado\":[],\"Domingo\":[]},\"Funfit\":{\"Lunes\":[],\"Martes\":[],\"Miércoles\":[],\"Jueves\":[],\"Viernes\":[\"19:00\"],\"Sábado\":[],\"Domingo\":[]}}";

    static final DateTimeFormatter F_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    static final DateTimeFormatter F_HMS = DateTimeFormatter.ofPattern("HH:mm:ss");
    static final DateTimeFormatter F_CORTA = DateTimeFormatter.ofPattern("dd/MM 'a las' HH:mm");

    // Colores (mismo estilo que la versión de PC)
    static final int C_FONDO = Color.parseColor("#0d1117");
    static final int C_PANEL = Color.parseColor("#161b22");
    static final int C_GRIS = Color.parseColor("#21262d");
    static final int C_TEXTO = Color.parseColor("#c9d1d9");
    static final int C_TENUE = Color.parseColor("#8b949e");
    static final int C_AZUL = Color.parseColor("#58a6ff");
    static final int C_VERDE = Color.parseColor("#238636");
    static final int C_VERDE_TXT = Color.parseColor("#3fb950");
    static final int C_ROJO = Color.parseColor("#da3633");

    // ─────────────────────────────────────────────────────────────
    //  ESTADO
    // ─────────────────────────────────────────────────────────────
    final Handler ui = new Handler(Looper.getMainLooper());
    SharedPreferences prefs;
    JSONObject horarios;

    WebView web;
    TextView txtLog;
    ScrollView scrollLog, scrollConfig;
    LinearLayout panelLog, listaFilas;
    EditText edEmail, edPass;
    Button btnActivar, btnRecargar, btnAtenuar, btnTabConfig, btnTabLog;

    final List<Fila> filas = new ArrayList<>();
    final ArrayDeque<String> lineasLog = new ArrayDeque<>();

    /** Hilo que está trabajando (bot o recarga). Si deja de ser él, se detiene. */
    volatile Thread trabajador = null;
    volatile boolean botActivo = false;
    volatile boolean cargandoHorarios = false;
    volatile boolean paginaCargando = false;
    volatile int anchoWebPx = 0;
    boolean atenuado = false;

    String email = "", password = "";
    List<Tarea> tareas = new ArrayList<>();

    /** Se lanza para cortar el hilo de trabajo cuando se pulsa Detener. */
    static class Detenido extends RuntimeException { }

    // ═════════════════════════════════════════════════════════════
    //  CICLO DE VIDA
    // ═════════════════════════════════════════════════════════════

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("config", MODE_PRIVATE);
        cargarHorarios();
        construirInterfaz();
        cargarConfig();
        log("Listo. 1) Guarda email y contraseña  2) Revisa las clases  3) Pulsa 'Activar bot'");
        log("La app debe quedarse ABIERTA y en pantalla para funcionar.");
    }

    @Override
    public void onBackPressed() {
        if (botActivo || cargandoHorarios) {
            new AlertDialog.Builder(this)
                    .setTitle("El bot está trabajando")
                    .setMessage("Si sales de la app, el bot deja de funcionar. ¿Salir igualmente?")
                    .setPositiveButton("Salir", (d, w) -> finish())
                    .setNegativeButton("Quedarme", null)
                    .show();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        trabajador = null;
        if (web != null) web.destroy();
        super.onDestroy();
    }

    // ═════════════════════════════════════════════════════════════
    //  INTERFAZ
    // ═════════════════════════════════════════════════════════════

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    TextView texto(String s, int sp, int color, boolean negrita) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (negrita) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    Button boton(String s, int fondo, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fondo);
        g.setCornerRadius(dp(6));
        b.setBackground(g);
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setOnClickListener(l);
        return b;
    }

    void colorBoton(Button b, int fondo) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fondo);
        g.setCornerRadius(dp(6));
        b.setBackground(g);
    }

    LinearLayout.LayoutParams lp(int w, int h, float peso) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, peso);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        return p;
    }

    EditText campo(boolean clave) {
        EditText e = new EditText(this);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(C_TENUE);
        e.setSingleLine(true);
        e.setInputType(clave
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        return e;
    }

    void construirInterfaz() {
        final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
        final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(C_FONDO);

        TextView titulo = texto("🧘 Reservas Almassora SEM", 18, C_AZUL, true);
        titulo.setGravity(Gravity.CENTER);
        titulo.setPadding(0, dp(10), 0, dp(4));
        raiz.addView(titulo);

        // Pestañas
        LinearLayout pestanas = new LinearLayout(this);
        btnTabConfig = boton("⚙️ Configuración", C_AZUL, v -> mostrarPestana(true));
        btnTabLog = boton("📋 Registro", C_GRIS, v -> mostrarPestana(false));
        pestanas.addView(btnTabConfig, lp(0, WRAP, 1));
        pestanas.addView(btnTabLog, lp(0, WRAP, 1));
        pestanas.setPadding(dp(6), 0, dp(6), 0);
        raiz.addView(pestanas);

        // Zona central: configuración o registro
        FrameLayout centro = new FrameLayout(this);
        scrollConfig = construirConfig();
        centro.addView(scrollConfig, new FrameLayout.LayoutParams(MATCH, MATCH));

        panelLog = new LinearLayout(this);
        panelLog.setOrientation(LinearLayout.VERTICAL);
        panelLog.addView(boton("📋 Copiar registro", C_GRIS, v -> copiarRegistro()), lp(MATCH, WRAP, 0));
        scrollLog = new ScrollView(this);
        txtLog = texto("", 11, C_VERDE_TXT, false);
        txtLog.setTypeface(Typeface.MONOSPACE);
        txtLog.setTextIsSelectable(true);
        txtLog.setPadding(dp(8), dp(4), dp(8), dp(4));
        scrollLog.addView(txtLog);
        scrollLog.setBackgroundColor(Color.parseColor("#010409"));
        panelLog.addView(scrollLog, new LinearLayout.LayoutParams(MATCH, 0, 1));
        panelLog.setVisibility(View.GONE);
        centro.addView(panelLog, new FrameLayout.LayoutParams(MATCH, MATCH));

        raiz.addView(centro, new LinearLayout.LayoutParams(MATCH, 0, 1));

        // Web del gimnasio (el bot la maneja; tiene que estar visible)
        TextView lblWeb = texto("🌐 Web del gimnasio (la maneja el bot, no hace falta tocarla)", 11, C_TENUE, false);
        lblWeb.setPadding(dp(8), dp(4), dp(8), dp(2));
        raiz.addView(lblWeb);

        web = new WebView(this);
        configurarWeb();
        int alto = (int) (getResources().getDisplayMetrics().heightPixels * 0.36);
        raiz.addView(web, new LinearLayout.LayoutParams(MATCH, alto));

        setContentView(raiz);
    }

    ScrollView construirConfig() {
        final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
        final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

        ScrollView sv = new ScrollView(this);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(10), dp(6), dp(10), dp(10));
        sv.addView(c);

        // Credenciales
        LinearLayout cred = new LinearLayout(this);
        cred.setOrientation(LinearLayout.VERTICAL);
        cred.setBackgroundColor(C_PANEL);
        cred.setPadding(dp(10), dp(8), dp(10), dp(8));
        cred.addView(texto("Email", 13, C_TEXTO, false));
        edEmail = campo(false);
        cred.addView(edEmail);
        cred.addView(texto("Contraseña", 13, C_TEXTO, false));
        edPass = campo(true);
        cred.addView(edPass);
        cred.addView(boton("💾 Guardar", C_GRIS, v -> {
            guardarConfig();
            log("💾 Credenciales y clases guardadas");
            Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show();
        }), lp(MATCH, WRAP, 0));
        c.addView(cred, lp(MATCH, WRAP, 0));

        // Clases
        TextView lbl = texto("📅 Clases a reservar", 15, Color.WHITE, true);
        lbl.setPadding(0, dp(10), 0, dp(4));
        c.addView(lbl);
        listaFilas = new LinearLayout(this);
        listaFilas.setOrientation(LinearLayout.VERTICAL);
        c.addView(listaFilas);
        c.addView(boton("＋ Añadir clase", C_GRIS, v -> agregarFila(null)), lp(MATCH, WRAP, 0));

        TextView info = texto("El bot se prepara " + (ANTELACION_LOGIN / 60) + " min antes de que abra cada reserva ("
                + DIAS_ANTES + " días y " + HORAS_ANTES + " h antes de la clase) y después busca hueco hasta que "
                + "empieza la clase. Deja la app abierta y el móvil cargando.", 12, C_TENUE, false);
        info.setPadding(0, dp(8), 0, dp(8));
        c.addView(info);

        btnActivar = boton("▶  Activar bot", C_VERDE, v -> pulsarActivar());
        btnActivar.setTextSize(16);
        c.addView(btnActivar, lp(MATCH, WRAP, 0));

        LinearLayout fila2 = new LinearLayout(this);
        btnRecargar = boton("🔄 Recargar horarios", C_GRIS, v -> pulsarRecargar());
        btnAtenuar = boton("🌙 Atenuar pantalla", C_GRIS, v -> alternarAtenuado());
        fila2.addView(btnRecargar, lp(0, WRAP, 1));
        fila2.addView(btnAtenuar, lp(0, WRAP, 1));
        c.addView(fila2);
        return sv;
    }

    void mostrarPestana(boolean config) {
        scrollConfig.setVisibility(config ? View.VISIBLE : View.GONE);
        panelLog.setVisibility(config ? View.GONE : View.VISIBLE);
        colorBoton(btnTabConfig, config ? C_AZUL : C_GRIS);
        colorBoton(btnTabLog, config ? C_GRIS : C_AZUL);
        if (!config) scrollLog.post(() -> scrollLog.fullScroll(View.FOCUS_DOWN));
    }

    void alternarAtenuado() {
        atenuado = !atenuado;
        WindowManager.LayoutParams p = getWindow().getAttributes();
        p.screenBrightness = atenuado ? 0.01f : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
        getWindow().setAttributes(p);
        btnAtenuar.setText(atenuado ? "☀️ Brillo normal" : "🌙 Atenuar pantalla");
    }

    void copiarRegistro() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("registro", TextUtils.join("\n", lineasLog)));
        Toast.makeText(this, "Registro copiado", Toast.LENGTH_SHORT).show();
    }

    void pantallaEncendida(boolean si) {
        if (si) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    void configurarWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBlockNetworkImage(true);   // sin imágenes: carga más rápido (como en el .py)
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return false;
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) {
                paginaCargando = true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                paginaCargando = false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
                log("   💬 Aviso de la web: " + msg);
                r.confirm();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
                log("   💬 La web pregunta: " + msg + " (se cancela)");
                r.cancel();
                return true;
            }
        });
        web.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> anchoWebPx = r - l);
    }

    // ─────────────────────────────────────────────────────────────
    //  FILAS DE RESERVA
    // ─────────────────────────────────────────────────────────────

    static int idxDia(LocalDate d) {
        return d.getDayOfWeek().getValue() - 1;   // lunes = 0
    }

    static String etiquetaFecha(String fecha) {
        LocalDate d = LocalDate.parse(fecha, F_FECHA);
        return DIAS_CORTOS[idxDia(d)] + " " + fecha;
    }

    static String fechaDeEtiqueta(String txt) {
        if (txt == null) return null;
        Matcher m = Pattern.compile("\\d{2}/\\d{2}/\\d{4}").matcher(txt);
        return m.find() ? m.group() : null;
    }

    static List<String> opcionesFecha() {
        List<String> l = new ArrayList<>();
        l.add(CADA_SEMANA);
        LocalDate hoy = LocalDate.now();
        for (int i = 0; i < DIAS_FECHAS; i++) l.add(etiquetaFecha(hoy.plusDays(i).format(F_FECHA)));
        return l;
    }

    List<String> clasesParaDia(String dia) {
        List<String> l = new ArrayList<>();
        Iterator<String> it = horarios.keys();
        while (it.hasNext()) {
            String k = it.next();
            JSONObject o = horarios.optJSONObject(k);
            if (o != null) {
                JSONArray a = o.optJSONArray(dia);
                if (a != null && a.length() > 0) l.add(k);
            }
        }
        return l;
    }

    List<String> horasPara(String clase, String dia) {
        List<String> l = new ArrayList<>();
        JSONObject o = horarios.optJSONObject(clase);
        if (o != null) {
            JSONArray a = o.optJSONArray(dia);
            if (a != null) for (int i = 0; i < a.length(); i++) l.add(a.optString(i));
        }
        return l;
    }

    ArrayAdapter<String> adaptador(List<String> items) {
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return a;
    }

    static abstract class AlElegir implements AdapterView.OnItemSelectedListener {
        abstract void elegido();

        @Override
        public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
            elegido();
        }

        @Override
        public void onNothingSelected(AdapterView<?> p) {
        }
    }

    class Fila {
        LinearLayout vista;
        Spinner spFecha, spDia, spClase, spHora;

        Fila(JSONObject r) {
            final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
            final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

            vista = new LinearLayout(MainActivity.this);
            vista.setOrientation(LinearLayout.VERTICAL);
            vista.setBackgroundColor(C_PANEL);
            vista.setPadding(dp(6), dp(4), dp(6), dp(4));

            LinearLayout l1 = new LinearLayout(MainActivity.this);
            l1.setGravity(Gravity.CENTER_VERTICAL);
            l1.addView(texto("Fecha", 12, C_TEXTO, false));
            spFecha = new Spinner(MainActivity.this);
            l1.addView(spFecha, lp(0, WRAP, 1.3f));
            l1.addView(texto("Día", 12, C_TEXTO, false));
            spDia = new Spinner(MainActivity.this);
            l1.addView(spDia, lp(0, WRAP, 1f));
            vista.addView(l1);

            LinearLayout l2 = new LinearLayout(MainActivity.this);
            l2.setGravity(Gravity.CENTER_VERTICAL);
            l2.addView(texto("Clase", 12, C_TEXTO, false));
            spClase = new Spinner(MainActivity.this);
            l2.addView(spClase, lp(0, WRAP, 1.4f));
            l2.addView(texto("Hora", 12, C_TEXTO, false));
            spHora = new Spinner(MainActivity.this);
            l2.addView(spHora, lp(0, WRAP, 0.9f));
            Button quitar = boton("✕", C_ROJO, v -> {
                listaFilas.removeView(vista);
                filas.remove(this);
            });
            l2.addView(quitar, lp(WRAP, WRAP, 0));
            vista.addView(l2);

            // Valores iniciales
            String fechaDef = (r == null || r.isNull("fecha")) ? null : r.optString("fecha", null);
            int diaDef = r == null ? 1 : r.optInt("dia_idx", 1);
            String claseDef = r == null ? null : r.optString("clase", null);
            String horaDef = r == null ? null : r.optString("hora", null);

            List<String> fechas = opcionesFecha();
            if (fechaDef != null && !fechas.contains(etiquetaFecha(fechaDef))) fechas.add(1, etiquetaFecha(fechaDef));
            spFecha.setAdapter(adaptador(fechas));
            spFecha.setSelection(fechaDef == null ? 0 : fechas.indexOf(etiquetaFecha(fechaDef)), false);

            spDia.setAdapter(adaptador(new ArrayList<>(Arrays.asList(DIAS_SEMANA))));
            spDia.setSelection(diaDef, false);
            aplicarFecha();
            actualizarClases(claseDef, horaDef);

            spFecha.setOnItemSelectedListener(new AlElegir() {
                void elegido() {
                    aplicarFecha();
                    actualizarClases(null, null);
                }
            });
            spDia.setOnItemSelectedListener(new AlElegir() {
                void elegido() {
                    actualizarClases(null, null);
                }
            });
            spClase.setOnItemSelectedListener(new AlElegir() {
                void elegido() {
                    actualizarHoras(null);
                }
            });

            LinearLayout.LayoutParams p = lp(MATCH, WRAP, 0);
            p.setMargins(0, dp(3), 0, dp(3));
            listaFilas.addView(vista, p);
        }

        String fecha() {
            return fechaDeEtiqueta((String) spFecha.getSelectedItem());
        }

        String dia() {
            return DIAS_SEMANA[spDia.getSelectedItemPosition()];
        }

        void aplicarFecha() {
            String f = fecha();
            if (f != null) {
                spDia.setSelection(idxDia(LocalDate.parse(f, F_FECHA)), false);
                spDia.setEnabled(false);
            } else {
                spDia.setEnabled(true);
            }
        }

        void actualizarClases(String deseada, String horaDeseada) {
            List<String> clases = clasesParaDia(dia());
            String actual = deseada != null ? deseada : (String) spClase.getSelectedItem();
            if (clases.isEmpty()) clases.add(SIN_VALOR);
            spClase.setAdapter(adaptador(clases));
            spClase.setSelection(Math.max(0, clases.indexOf(actual)), false);
            actualizarHoras(horaDeseada);
        }

        void actualizarHoras(String deseada) {
            List<String> horas = horasPara((String) spClase.getSelectedItem(), dia());
            String actual = deseada != null ? deseada : (String) spHora.getSelectedItem();
            if (horas.isEmpty()) horas.add(SIN_VALOR);
            spHora.setAdapter(adaptador(horas));
            spHora.setSelection(Math.max(0, horas.indexOf(actual)), false);
        }

        boolean valida() {
            return !SIN_VALOR.equals(spClase.getSelectedItem()) && !SIN_VALOR.equals(spHora.getSelectedItem());
        }

        JSONObject json() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("dia_idx", spDia.getSelectedItemPosition());
            o.put("dia", dia());
            o.put("clase", spClase.getSelectedItem());
            o.put("hora", spHora.getSelectedItem());
            String f = fecha();
            o.put("fecha", f == null ? JSONObject.NULL : f);
            return o;
        }
    }

    void agregarFila(JSONObject r) {
        filas.add(new Fila(r));
    }

    void refrescarFilas() {
        for (Fila f : filas) f.actualizarClases(null, null);
    }

    // ─────────────────────────────────────────────────────────────
    //  PERSISTENCIA
    // ─────────────────────────────────────────────────────────────

    void cargarHorarios() {
        try {
            horarios = new JSONObject(prefs.getString("horarios", HORARIOS_DEFECTO));
        } catch (JSONException e) {
            try {
                horarios = new JSONObject(HORARIOS_DEFECTO);
            } catch (JSONException e2) {
                horarios = new JSONObject();
            }
        }
    }

    void guardarHorarios() {
        prefs.edit().putString("horarios", horarios.toString()).apply();
    }

    void cargarConfig() {
        edEmail.setText(prefs.getString("email", ""));
        edPass.setText(prefs.getString("password", ""));
        JSONArray reservas = null;
        try {
            String s = prefs.getString("reservas", null);
            if (s != null) reservas = new JSONArray(s);
        } catch (JSONException ignored) {
        }
        if (reservas != null && reservas.length() > 0) {
            for (int i = 0; i < reservas.length(); i++) agregarFila(reservas.optJSONObject(i));
        } else {
            try {
                agregarFila(new JSONObject().put("dia_idx", 1).put("clase", "Aquagym").put("hora", "20:20"));
                agregarFila(new JSONObject().put("dia_idx", 3).put("clase", "Aquagym").put("hora", "20:20"));
            } catch (JSONException ignored) {
            }
        }
    }

    void guardarConfig() {
        JSONArray a = new JSONArray();
        for (Fila f : filas) {
            try {
                if (f.valida()) a.put(f.json());
            } catch (JSONException ignored) {
            }
        }
        prefs.edit()
                .putString("email", edEmail.getText().toString().trim())
                .putString("password", edPass.getText().toString())
                .putString("reservas", a.toString())
                .apply();
    }

    // ─────────────────────────────────────────────────────────────
    //  LOG
    // ─────────────────────────────────────────────────────────────

    void log(String m) {
        final String linea = "[" + LocalTime.now().format(F_HMS) + "] " + m;
        ui.post(() -> {
            lineasLog.addLast(linea);
            while (lineasLog.size() > MAX_LINEAS_LOG) lineasLog.removeFirst();
            txtLog.setText(TextUtils.join("\n", lineasLog));
            scrollLog.post(() -> scrollLog.fullScroll(View.FOCUS_DOWN));
        });
    }

    void avisoExito(String que) {
        ui.post(() -> {
            try {
                ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);
                tg.startTone(ToneGenerator.TONE_PROP_ACK, 600);
                ui.postDelayed(tg::release, 1000);
            } catch (Exception ignored) {
            }
            Toast.makeText(this, "🎉 ¡Reservado! " + que, Toast.LENGTH_LONG).show();
        });
    }

    // ═════════════════════════════════════════════════════════════
    //  BOTONES
    // ═════════════════════════════════════════════════════════════

    void pulsarActivar() {
        if (botActivo) {
            detenerTrabajo();
            return;
        }
        if (cargandoHorarios) {
            Toast.makeText(this, "Espera a que termine la recarga de horarios", Toast.LENGTH_SHORT).show();
            return;
        }
        guardarConfig();
        email = edEmail.getText().toString().trim();
        password = edPass.getText().toString();
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Escribe tu email y contraseña", Toast.LENGTH_LONG).show();
            return;
        }
        List<Tarea> nuevas = new ArrayList<>();
        for (Fila f : filas) {
            if (!f.valida()) continue;
            Tarea t = new Tarea();
            t.dia = f.spDia.getSelectedItemPosition();
            t.clase = (String) f.spClase.getSelectedItem();
            t.hora = (String) f.spHora.getSelectedItem();
            t.fecha = f.fecha();
            nuevas.add(t);
        }
        if (nuevas.isEmpty()) {
            Toast.makeText(this, "Añade al menos una clase con hora válida", Toast.LENGTH_LONG).show();
            return;
        }
        tareas = nuevas;
        botActivo = true;
        btnActivar.setText("⏹  Detener bot");
        colorBoton(btnActivar, C_ROJO);
        btnRecargar.setEnabled(false);
        pantallaEncendida(true);
        mostrarPestana(false);

        Thread h = new Thread(this::bucleBot, "bot");
        trabajador = h;
        h.start();
    }

    void detenerTrabajo() {
        Thread h = trabajador;
        trabajador = null;
        if (h != null) h.interrupt();
        log("⏹ Bot detenido por el usuario.");
        trabajoTerminado();
    }

    void trabajoTerminado() {
        ui.post(() -> {
            if (trabajador != null) return;   // ya hay otro trabajo en marcha
            botActivo = false;
            cargandoHorarios = false;
            btnActivar.setText("▶  Activar bot");
            colorBoton(btnActivar, C_VERDE);
            btnActivar.setEnabled(true);
            btnRecargar.setEnabled(true);
            btnRecargar.setText("🔄 Recargar horarios");
            pantallaEncendida(false);
        });
    }

    void pulsarRecargar() {
        if (botActivo || cargandoHorarios) return;
        email = edEmail.getText().toString().trim();
        password = edPass.getText().toString();
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Escribe tu email y contraseña", Toast.LENGTH_LONG).show();
            return;
        }
        guardarConfig();
        cargandoHorarios = true;
        btnRecargar.setEnabled(false);
        btnRecargar.setText("⏳ Cargando...");
        btnActivar.setEnabled(false);
        pantallaEncendida(true);
        mostrarPestana(false);
        Thread h = new Thread(this::recargarHorarios, "horarios");
        trabajador = h;
        h.start();
    }

    // ═════════════════════════════════════════════════════════════
    //  UTILIDADES PARA MANEJAR LA WEB (equivalentes a Playwright)
    // ═════════════════════════════════════════════════════════════

    void comprobarSeguir() {
        if (Thread.currentThread() != trabajador) throw new Detenido();
    }

    void dormir(long ms) {
        comprobarSeguir();
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            throw new Detenido();
        }
        comprobarSeguir();
    }

    /** Funciones JS auxiliares que se incluyen en cada evaluación. */
    static final String H =
            "function norm(s){return (s||'').replace(/\\s+/g,' ').trim().toLowerCase();}" +
            "function txt(e){return e.tagName==='INPUT'?(e.value||''):(e.textContent||'');}" +
            "function vis(e){return !!(e.offsetWidth||e.offsetHeight||e.getClientRects().length);}" +
            "function porTexto(t){t=norm(t);if(!document.body)return null;" +
            "  var all=document.body.querySelectorAll('*');var cand=null;" +
            "  for(var i=0;i<all.length;i++){var e=all[i];" +
            "    if(e.tagName==='SCRIPT'||e.tagName==='STYLE')continue;" +
            "    if(norm(txt(e)).indexOf(t)<0)continue;" +
            "    var inner=true;for(var j=0;j<e.children.length;j++){" +
            "      if(norm(txt(e.children[j])).indexOf(t)>=0){inner=false;break;}}" +
            "    if(!inner)continue;if(vis(e))return e;if(!cand)cand=e;}" +
            "  return cand;}" +
            "function clic(e){var x=e.closest('a,button,input[type=submit],input[type=button],[onclick],[role=button]')||e;" +
            "  try{x.scrollIntoView({block:'center'});}catch(_){}x.click();return true;}" +
            "function boton(t){t=norm(t);" +
            "  var bs=document.querySelectorAll('button,input[type=submit],input[type=button],[role=button],a.btn');" +
            "  var cand=null;for(var i=0;i<bs.length;i++){var b=bs[i];" +
            "    var s=norm(b.tagName==='INPUT'?b.value:(b.innerText||b.textContent));" +
            "    if(s.indexOf(t)<0)continue;if(vis(b))return b;if(!cand)cand=b;}" +
            "  return cand;}" +
            "function hh(t){var p=(t||'').trim().split(':');if(p.length!==2)return t;" +
            "  return (p[0].length<2?'0':'')+p[0]+':'+p[1];}";

    static String q(String s) {
        return JSONObject.quote(s);
    }

    /** Envuelve un cuerpo JS (con 'return') en una función con las utilidades. */
    static String f(String cuerpo) {
        return "(function(){" + H + cuerpo + "})()";
    }

    /** Ejecuta JS en la página y devuelve el resultado en bruto (JSON). */
    String js(final String codigo) {
        comprobarSeguir();
        final CountDownLatch hecho = new CountDownLatch(1);
        final AtomicReference<String> res = new AtomicReference<>("null");
        ui.post(() -> {
            try {
                web.evaluateJavascript(codigo, v -> {
                    res.set(v == null ? "null" : v);
                    hecho.countDown();
                });
            } catch (Exception e) {
                hecho.countDown();
            }
        });
        try {
            hecho.await(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            throw new Detenido();
        }
        comprobarSeguir();
        return res.get();
    }

    String jsTexto(String codigo) {
        String raw = js(codigo);
        try {
            Object o = new JSONArray("[" + raw + "]").get(0);
            return o == JSONObject.NULL ? "" : String.valueOf(o);
        } catch (JSONException e) {
            return "";
        }
    }

    boolean jsBool(String codigo) {
        return "true".equals(js(codigo));
    }

    /** Espera hasta que la condición JS sea verdadera (como wait_for_selector). */
    boolean esperar(String condicion, long ms) {
        long fin = SystemClock.elapsedRealtime() + ms;
        String c = f("try{return !!(" + condicion + ");}catch(e){return false;}");
        while (true) {
            if (jsBool(c)) return true;
            if (SystemClock.elapsedRealtime() > fin) return false;
            dormir(250);
        }
    }

    static String hayTexto(String t) {
        return "norm(document.body?document.body.innerText:'').indexOf(norm(" + q(t) + "))>=0";
    }

    static final String CAL_LISTO = "document.querySelector('" + INLINE + " td[data-day]')!==null";

    /** Espera a que la web termine de cargar (como networkidle). */
    void esperarInactiva(long ms) {
        String c = f("if(document.readyState!=='complete')return false;" +
                "try{if(window.Sys&&Sys.WebForms&&Sys.WebForms.PageRequestManager&&" +
                "Sys.WebForms.PageRequestManager.getInstance().get_isInAsyncPostBack())return false;}catch(e){}" +
                "try{if(window.jQuery&&jQuery.active>0)return false;}catch(e){}" +
                "return true;");
        long fin = SystemClock.elapsedRealtime() + ms;
        int seguidas = 0;
        while (SystemClock.elapsedRealtime() < fin) {
            if (!paginaCargando && jsBool(c)) {
                if (++seguidas >= 2) return;
            } else {
                seguidas = 0;
            }
            dormir(250);
        }
    }

    boolean clicTexto(String t) {
        return jsBool(f("var e=porTexto(" + q(t) + ");if(!e)return false;return clic(e);"));
    }

    boolean clicBoton(String t) {
        return jsBool(f("var b=boton(" + q(t) + ");if(!b)return false;" +
                "try{b.scrollIntoView({block:'center'});}catch(_){}b.click();return true;"));
    }

    boolean rellenar(String selector, String valor) {
        return jsBool(f("var e=document.querySelector(" + q(selector) + ");if(!e)return false;" +
                "e.focus();e.value=" + q(valor) + ";" +
                "e.dispatchEvent(new Event('input',{bubbles:true}));" +
                "e.dispatchEvent(new Event('change',{bubbles:true}));return true;"));
    }

    /** Toque "físico" en la web, como el clic de ratón del .py. */
    void tocar(final float x, final float y) {
        ui.post(() -> {
            long t = SystemClock.uptimeMillis();
            MotionEvent d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
            web.dispatchTouchEvent(d);
            d.recycle();
            ui.postDelayed(() -> {
                MotionEvent u = MotionEvent.obtain(t, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, x, y, 0);
                web.dispatchTouchEvent(u);
                u.recycle();
            }, 60);
        });
    }

    // ─────────────────────────────────────────────────────────────
    //  NAVEGACIÓN COMÚN
    // ─────────────────────────────────────────────────────────────

    /** Login + ir a Reserva clases SEM + Almassora. Deja el calendario listo. */
    void login() throws Exception {
        log("   🌐 Iniciando sesión...");
        ui.post(() -> {
            CookieManager cm = CookieManager.getInstance();
            cm.removeAllCookies(ok -> {
                cm.flush();
                web.loadUrl(BASE_URL);
            });
        });
        dormir(1500);
        if (!esperar(hayTexto("Acceso identificado"), 25000))
            throw new Exception("no carga la página de inicio de sesión (¿hay internet?)");
        clicTexto("Acceso identificado");
        if (!esperar("document.querySelector('input[placeholder=\"Identificador\"]')", 10000))
            throw new Exception("no aparece el formulario de acceso");
        rellenar("input[placeholder=\"Identificador\"]", email);
        rellenar("input[placeholder=\"Contraseña\"]", password);
        if (!clicBoton("Iniciar sesión")) throw new Exception("no encuentro el botón 'Iniciar sesión'");
        esperarInactiva(15000);

        if (!esperar(hayTexto("Reserva clases SEM"), 15000))
            throw new Exception("no se pudo entrar. ¿Email y contraseña correctos?");
        clicTexto("Reserva clases SEM");
        esperarInactiva(15000);

        if (!esperar(hayTexto("Almassora - Servei Esportiu Municipal"), 15000))
            throw new Exception("no aparece 'Almassora - Servei Esportiu Municipal'");
        clicTexto("Almassora - Servei Esportiu Municipal");
        esperarInactiva(15000);

        if (!esperar(CAL_LISTO, 15000)) throw new Exception("no aparece el calendario de clases");
        esperar("document.querySelector('div.panel.panel-default')", 10000);
        dormir(1000);
        log("   ✅ Sesión iniciada");
    }

    String diaActivo() {
        return jsTexto(f("var c=document.querySelector(" + q(INLINE) + ");if(!c)return '(no-inline)';" +
                "var e=c.querySelector('td.day.active[data-day]');return e?e.getAttribute('data-day'):'(ninguno)';"));
    }

    String mesMostrado() {
        return jsTexto(f("var c=document.querySelector(" + q(INLINE) + ");if(!c)return '';" +
                "var s=c.querySelector('.picker-switch[data-action=\"pickerSwitch\"]');" +
                "return s?s.textContent.trim().toLowerCase():'';"));
    }

    String fotoContenido() {
        return jsTexto(f("var t=[];" +
                "document.querySelectorAll('div.panel.panel-default h4.media-heading').forEach(function(h){t.push(h.textContent.trim());});" +
                "document.querySelectorAll('ul.media-list li span').forEach(function(s){t.push(s.textContent.trim());});" +
                "return t.join('|');"));
    }

    /** Selecciona el día (DD/MM/YYYY) en el calendario. Igual que _seleccionar_dia del .py. */
    boolean seleccionarDia(String dataDay) {
        String[] p = dataDay.split("/");
        int mm = Integer.parseInt(p[1]);
        int yyyy = Integer.parseInt(p[2]);
        String mesObj = MESES[mm - 1] + " " + yyyy;

        if (dataDay.equals(diaActivo())
                && jsBool("document.querySelectorAll('div.panel.panel-default').length>0")) {
            return true;
        }
        String antes = fotoContenido();

        // 1) Ir al mes correcto
        for (int i = 0; i < 14; i++) {
            String actual = mesMostrado();
            if (actual.equals(mesObj)) break;
            boolean siguiente = true;
            String[] partes = actual.split(" ");
            int im = partes.length == 2 ? Arrays.asList(MESES).indexOf(partes[0]) : -1;
            if (im >= 0) {
                try {
                    siguiente = Integer.parseInt(partes[1]) * 12 + im < yyyy * 12 + (mm - 1);
                } catch (NumberFormatException ignored) {
                }
            }
            String acc = siguiente ? "next" : "previous";
            js(f("var c=document.querySelector(" + q(INLINE) + ");if(!c)return false;" +
                    "var b=c.querySelector('th." + acc + ", [data-action=\"" + acc + "\"]');if(b)b.click();return true;"));
            dormir(500);
        }

        // 2) Toque en la celda del día
        String caja = jsTexto(f("var c=document.querySelector(" + q(INLINE) + ");if(!c)return '';" +
                "var e=c.querySelector('td[data-day=\"" + dataDay + "\"]');if(!e)return '';" +
                "e.scrollIntoView({block:'center'});var r=e.getBoundingClientRect();" +
                "return JSON.stringify({x:r.left+r.width/2,y:r.top+r.height/2,w:r.width,h:r.height,iw:window.innerWidth});"));
        if (caja.isEmpty()) {
            log("      ⚠️ Día " + dataDay + " no encontrado en el calendario");
            return false;
        }
        boolean tocado = false;
        try {
            JSONObject c = new JSONObject(caja);
            double iw = c.optDouble("iw", 0);
            if (c.optDouble("w", 0) > 0 && c.optDouble("h", 0) > 0 && iw > 0 && anchoWebPx > 0) {
                double esc = anchoWebPx / iw;
                tocar((float) (c.getDouble("x") * esc), (float) (c.getDouble("y") * esc));
                tocado = true;
            }
        } catch (JSONException ignored) {
        }
        String clicJs = f("var c=document.querySelector(" + q(INLINE) + ");if(!c)return false;" +
                "var e=c.querySelector('td[data-day=\"" + dataDay + "\"]');if(!e)return false;e.click();return true;");
        if (!tocado) js(clicJs);

        // 3) Esperar a que cambien el día activo y el contenido
        boolean cambioDia = false, cambioContenido = false;
        for (int i = 0; i < 30; i++) {
            dormir(500);
            esperarInactiva(1500);
            if (dataDay.equals(diaActivo())) cambioDia = true;
            if (!fotoContenido().equals(antes)) cambioContenido = true;
            if (cambioDia && cambioContenido) break;
            if (i == 4 && !cambioDia) js(clicJs);   // plan B: clic por código
        }
        dormir(1000);
        if (cambioDia && !cambioContenido)
            log("      ⚠️ El día cambió pero el contenido no se actualizó");
        return cambioDia || dataDay.equals(diaActivo());
    }

    // ═════════════════════════════════════════════════════════════
    //  RECARGA DE HORARIOS
    // ═════════════════════════════════════════════════════════════

    static final String JS_EXTRAER = f(
            "var re=/^\\d{1,2}:\\d{2}$/;var out={};" +
            "var todos=[].slice.call(document.querySelectorAll('div.panel.panel-default'));" +
            "var pan=todos.filter(function(p){return p.querySelectorAll('div.panel.panel-default').length===0;});" +
            "pan.forEach(function(panel){" +
            "  var hs=[].slice.call(panel.querySelectorAll('h4.media-heading'));var nombre=null;" +
            "  for(var i=0;i<hs.length;i++){var t=(hs[i].textContent||'').trim();" +
            "    if(t&&!re.test(t)){nombre=t.replace(/\\s+/g,' ');break;}}" +
            "  if(!nombre)return;" +
            "  panel.querySelectorAll('ul.media-list li').forEach(function(li){" +
            "    if(li.closest('div.panel.panel-default')!==panel)return;" +
            "    var h=li.querySelector('h4.media-heading');if(!h)return;" +
            "    var t=(h.textContent||'').trim();if(!re.test(t))return;" +
            "    out[nombre]=out[nombre]||[];var x=hh(t);if(out[nombre].indexOf(x)<0)out[nombre].push(x);});" +
            "});" +
            "for(var k in out)out[k].sort();return JSON.stringify(out);");

    void recargarHorarios() {
        log("🔄 Recargando clases y horarios desde la web...");
        try {
            login();
            JSONObject nuevos = new JSONObject();
            LocalDate hoy = LocalDate.now();
            for (int idx = 0; idx < 7; idx++) {
                String dia = DIAS_SEMANA[idx];
                int delta = ((idx - idxDia(hoy)) % 7 + 7) % 7;
                // Para el día de hoy, primero la semana que viene
                int[] deltas = delta == 0 ? new int[]{7, 0} : new int[]{delta};
                JSONObject clasesDia = new JSONObject();
                for (int d : deltas) {
                    String dataDay = hoy.plusDays(d).format(F_FECHA);
                    if (!seleccionarDia(dataDay))
                        log("   ⚠️ " + dia + " (" + dataDay + "): no se pudo seleccionar el día");
                    dormir(3000);
                    try {
                        clasesDia = new JSONObject(jsTexto(JS_EXTRAER));
                    } catch (JSONException e) {
                        clasesDia = new JSONObject();
                    }
                    if (clasesDia.length() > 0) break;
                }
                if (clasesDia.length() == 0) {
                    log("   📅 " + dia + ": sin clases");
                    continue;
                }
                Iterator<String> it = clasesDia.keys();
                while (it.hasNext()) {
                    String nombre = it.next();
                    JSONObject porDia = nuevos.optJSONObject(nombre);
                    if (porDia == null) {
                        porDia = new JSONObject();
                        for (String ds : DIAS_SEMANA) porDia.put(ds, new JSONArray());
                        nuevos.put(nombre, porDia);
                    }
                    porDia.put(dia, clasesDia.getJSONArray(nombre));
                    log("   📅 " + dia + ": " + nombre + " → " + clasesDia.getJSONArray(nombre));
                }
            }
            if (nuevos.length() == 0) {
                log("⚠️ No se pudieron obtener horarios. Se mantienen los anteriores.");
                return;
            }
            // Conservar días que salieron vacíos pero antes tenían clases
            for (String dia : DIAS_SEMANA) {
                boolean hay = false;
                Iterator<String> it = nuevos.keys();
                while (it.hasNext()) {
                    JSONArray a = nuevos.getJSONObject(it.next()).optJSONArray(dia);
                    if (a != null && a.length() > 0) hay = true;
                }
                if (hay) continue;
                boolean conservadas = false;
                Iterator<String> it2 = horarios.keys();
                while (it2.hasNext()) {
                    String nombre = it2.next();
                    JSONArray a = horarios.getJSONObject(nombre).optJSONArray(dia);
                    if (a == null || a.length() == 0) continue;
                    JSONObject porDia = nuevos.optJSONObject(nombre);
                    if (porDia == null) {
                        porDia = new JSONObject();
                        for (String ds : DIAS_SEMANA) porDia.put(ds, new JSONArray());
                        nuevos.put(nombre, porDia);
                    }
                    porDia.put(dia, a);
                    conservadas = true;
                }
                if (conservadas) log("   ♻️ " + dia + ": la web no devolvió clases; se conservan las guardadas");
            }
            final JSONObject resultado = nuevos;
            ui.post(() -> {
                horarios = resultado;
                guardarHorarios();
                refrescarFilas();
            });
            log("✅ Horarios actualizados.");
        } catch (Detenido d) {
            // detenido por el usuario
        } catch (Exception e) {
            log("❌ Error al recargar horarios: " + e.getMessage());
        } finally {
            if (Thread.currentThread() == trabajador) trabajador = null;
            trabajoTerminado();
        }
    }

    // ═════════════════════════════════════════════════════════════
    //  RESERVA
    // ═════════════════════════════════════════════════════════════

    /** Una clase a reservar (una "ocurrencia" concreta de ella). */
    class Tarea {
        int dia;
        String clase, hora, fecha;   // fecha == null → cada semana
        LocalDateTime inicio, apertura;
        boolean terminada, preparada;
        int intentos;

        void calcular(LocalDateTime desde) {
            LocalTime h = LocalTime.parse(hora);
            if (fecha != null) {
                inicio = LocalDate.parse(fecha, F_FECHA).atTime(h);
                if (!inicio.isAfter(desde)) terminada = true;
            } else {
                LocalDate d = desde.toLocalDate();
                int delta = ((dia - idxDia(d)) % 7 + 7) % 7;
                inicio = d.plusDays(delta).atTime(h);
                if (!inicio.isAfter(desde)) inicio = inicio.plusDays(7);
            }
            apertura = inicio.minusDays(DIAS_ANTES).minusHours(HORAS_ANTES);
            preparada = false;
            intentos = 0;
        }

        String dataDay() {
            return inicio.format(F_FECHA);
        }

        String diaPrevio() {
            return inicio.minusDays(1).format(F_FECHA);
        }

        String nombre() {
            return clase + " " + hora + " (" + DIAS_CORTOS[dia] + " " + inicio.format(DateTimeFormatter.ofPattern("dd/MM")) + ")";
        }

        /** Pasa a la semana siguiente (o termina si era de fecha concreta). */
        void siguiente() {
            if (fecha != null) {
                terminada = true;
            } else {
                calcular(inicio.plusMinutes(1));
                log("   📌 Siguiente: " + nombre() + " → abre el " + apertura.format(F_CORTA));
            }
        }
    }

    static LocalDateTime ahora() {
        return LocalDateTime.now();
    }

    boolean tocaPreparar(Tarea t, LocalDateTime ahora) {
        return !t.terminada && !t.preparada
                && !ahora.isBefore(t.apertura.minusSeconds(ANTELACION_LOGIN))
                && ahora.isBefore(t.apertura);
    }

    /** Espera 'seg' segundos, pero corta antes si hay que prepararse para una apertura. */
    void esperarSegundos(int seg) {
        long fin = SystemClock.elapsedRealtime() + seg * 1000L;
        while (SystemClock.elapsedRealtime() < fin) {
            LocalDateTime a = ahora();
            for (Tarea t : tareas) if (tocaPreparar(t, a)) return;
            dormir(200);
        }
    }

    void bucleBot() {
        log("");
        log("════════════════════════════════");
        log("⏰ BOT ACTIVO — reservas programadas:");
        LocalDateTime ini = ahora();
        for (Tarea t : tareas) {
            t.calcular(ini);
            if (t.terminada) {
                log("   ⏭ " + t.clase + " " + t.hora + " del " + t.fecha + ": ya ha pasado, se ignora");
            } else if (!ini.isBefore(t.apertura)) {
                log("   🟢 " + t.nombre() + ": la reserva ya está abierta. Se busca hueco ahora.");
            } else {
                log("   📌 " + t.nombre() + (t.fecha != null ? " (solo esa fecha)" : " (cada semana)")
                        + " → abre el " + t.apertura.format(F_CORTA));
            }
        }
        log("════════════════════════════════");
        log("No cierres la app ni apagues la pantalla.");

        boolean sesion = false;
        int erroresSeguidos = 0;
        try {
            while (true) {
                comprobarSeguir();
                LocalDateTime ahora = ahora();

                // Clases que ya han empezado
                boolean quedan = false;
                for (Tarea t : tareas) {
                    if (t.terminada) continue;
                    if (!ahora.isBefore(t.inicio)) {
                        log("⏹ " + t.nombre() + ": la clase ya ha empezado. Dejo de buscar.");
                        t.siguiente();
                    }
                    if (!t.terminada) quedan = true;
                }
                if (!quedan) {
                    log("✅ No quedan reservas pendientes. Bot detenido.");
                    break;
                }

                // ¿Hay que prepararse para una apertura?
                Tarea prep = null;
                for (Tarea t : tareas)
                    if (tocaPreparar(t, ahora) && (prep == null || t.apertura.isBefore(prep.apertura))) prep = t;
                if (prep != null) {
                    for (Tarea t : tareas) if (!t.terminada && t.apertura.equals(prep.apertura)) t.preparada = true;
                    log("");
                    log("⏳ " + prep.nombre() + ": abre a las " + prep.apertura.format(F_HMS) + ". Preparando sesión...");
                    try {
                        login();
                        seleccionarDia(prep.diaPrevio());
                        sesion = true;
                        erroresSeguidos = 0;
                        log("   ✅ Listo. Esperando al segundo exacto de apertura...");
                    } catch (Detenido d) {
                        throw d;
                    } catch (Exception e) {
                        sesion = false;
                        log("   ⚠️ No se pudo preparar la sesión (" + e.getMessage() + "). Se reintentará en la apertura.");
                    }
                    while (ahora().isBefore(prep.apertura)) dormir(100);
                    log("⏱ ¡APERTURA " + ahora().format(F_HMS) + "! Lanzando reserva");
                }

                // Clases con la reserva abierta
                ahora = ahora();
                List<Tarea> activas = new ArrayList<>();
                for (Tarea t : tareas)
                    if (!t.terminada && !ahora.isBefore(t.apertura) && ahora.isBefore(t.inicio)) activas.add(t);
                if (activas.isEmpty()) {
                    dormir(1000);
                    continue;
                }
                activas.sort((a, b) -> b.apertura.compareTo(a.apertura));   // las recién abiertas primero

                // Sesión
                if (!sesion || erroresSeguidos >= ERRORES_PARA_RELOGIN) {
                    if (erroresSeguidos >= ERRORES_PARA_RELOGIN)
                        log("🔑 Varios errores seguidos: vuelvo a iniciar sesión...");
                    erroresSeguidos = 0;
                    try {
                        login();
                        sesion = true;
                    } catch (Detenido d) {
                        throw d;
                    } catch (Exception e) {
                        sesion = false;
                        log("❌ No se pudo iniciar sesión: " + e.getMessage());
                        esperarSegundos(ESPERA_REINTENTO);
                        continue;
                    }
                }

                boolean rapido = false;
                for (Tarea t : activas) {
                    comprobarSeguir();
                    if (!ahora().isBefore(t.inicio)) continue;
                    t.intentos++;
                    log("🔄 " + t.nombre() + " — intento " + t.intentos);
                    String r = intento(t);
                    switch (r) {
                        case "ok":
                            log("🎉 ¡RESERVA CONFIRMADA! " + t.nombre());
                            avisoExito(t.nombre());
                            erroresSeguidos = 0;
                            t.siguiente();
                            break;
                        case "ya_reservada":
                            log("⚠️ Ya tienes una reserva ese día. No se reintenta.");
                            erroresSeguidos = 0;
                            t.siguiente();
                            break;
                        case "llena":
                            erroresSeguidos = 0;
                            break;
                        default:
                            erroresSeguidos++;
                    }
                    if (!t.terminada && ahora().isBefore(t.apertura.plusSeconds(DURACION_RAPIDA))) rapido = true;
                }
                int espera = rapido ? ESPERA_RAPIDA : ESPERA_REINTENTO;
                log("   ⏸ Vuelvo a mirar en " + espera + "s");
                esperarSegundos(espera);
            }
        } catch (Detenido d) {
            // detenido por el usuario
        } catch (Exception e) {
            log("❌ Error grave: " + e);
        } finally {
            if (Thread.currentThread() == trabajador) trabajador = null;
            trabajoTerminado();
        }
    }

    static String jsEstadoClase(String nombre, String hora) {
        return f("var re=/^\\d{1,2}:\\d{2}$/;var nombre=" + q(nombre) + ".replace(/\\s+/g,' ');var hora=hh(" + q(hora) + ");" +
                "var todos=[].slice.call(document.querySelectorAll('div.panel.panel-default'));" +
                "var pan=todos.filter(function(p){return p.querySelectorAll('div.panel.panel-default').length===0;});" +
                "for(var i=0;i<pan.length;i++){var panel=pan[i];" +
                "  var hs=[].slice.call(panel.querySelectorAll('h4.media-heading')).map(function(h){return (h.textContent||'').trim().replace(/\\s+/g,' ');});" +
                "  var nom=null;for(var j=0;j<hs.length;j++){if(hs[j]&&!re.test(hs[j])){nom=hs[j];break;}}" +
                "  if(nom!==nombre)continue;" +
                "  var lis=panel.querySelectorAll('ul.media-list li');" +
                "  for(var k=0;k<lis.length;k++){var li=lis[k];" +
                "    if(li.closest('div.panel.panel-default')!==panel)continue;" +
                "    var h=li.querySelector('h4.media-heading');" +
                "    if(!h||hh(h.textContent)!==hora)continue;" +
                "    var sp=li.querySelectorAll('span');var oc=null,tot=null;" +
                "    if(sp.length>=2){oc=parseInt((sp[0].textContent||'').replace(/\\D/g,''));tot=parseInt((sp[1].textContent||'').replace(/\\D/g,''));}" +
                "    var lleno=(oc!==null&&tot!==null&&tot>0&&oc>=tot);" +
                "    return JSON.stringify({encontrado:true,lleno:lleno,aforo:oc+'/'+tot,li:k,panel:i});" +
                "  }" +
                "}" +
                "return JSON.stringify({encontrado:false});");
    }

    static String jsClicClase(String nombre, String hora) {
        return f("var re=/^\\d{1,2}:\\d{2}$/;var nombre=" + q(nombre) + ".replace(/\\s+/g,' ');var hora=hh(" + q(hora) + ");" +
                "var todos=[].slice.call(document.querySelectorAll('div.panel.panel-default'));" +
                "var pan=todos.filter(function(p){return p.querySelectorAll('div.panel.panel-default').length===0;});" +
                "for(var i=0;i<pan.length;i++){var panel=pan[i];" +
                "  var hs=[].slice.call(panel.querySelectorAll('h4.media-heading')).map(function(h){return (h.textContent||'').trim().replace(/\\s+/g,' ');});" +
                "  var nom=null;for(var j=0;j<hs.length;j++){if(hs[j]&&!re.test(hs[j])){nom=hs[j];break;}}" +
                "  if(nom!==nombre)continue;" +
                "  var lis=panel.querySelectorAll('ul.media-list li');" +
                "  for(var k=0;k<lis.length;k++){var li=lis[k];" +
                "    if(li.closest('div.panel.panel-default')!==panel)continue;" +
                "    var h=li.querySelector('h4.media-heading');" +
                "    if(!h||hh(h.textContent)!==hora)continue;" +
                "    var a=li.querySelector('a');if(a){a.click();return true;}" +
                "    li.click();return true;" +
                "  }" +
                "}" +
                "return false;");
    }

    static final String JS_RESULTADO = f(
            "var cs=document.querySelectorAll('[id$=\"uAlert_uplAlert\"]');" +
            "for(var i=0;i<cs.length;i++){var al=cs[i].querySelector('.alert');" +
            "  if(al&&al.innerText.trim().length>0){var cls=al.className||'';var tipo='desconocido';" +
            "    if(cls.indexOf('alert-success')>=0)tipo='ok';" +
            "    else if(cls.indexOf('alert-danger')>=0||cls.indexOf('alert-warning')>=0)tipo='error';" +
            "    return JSON.stringify({tipo:tipo,texto:al.innerText.replace(/\\s*x\\s*$/,'').trim(),fuente:'uAlert'});}}" +
            "var su=document.querySelector('.alert-success, [class*=\"success\"]');" +
            "if(su&&su.offsetParent!==null&&su.innerText.trim())return JSON.stringify({tipo:'ok',texto:su.innerText.trim(),fuente:'generic'});" +
            "var da=document.querySelector('.alert-danger, .alert-warning');" +
            "if(da&&da.offsetParent!==null&&da.innerText.trim())return JSON.stringify({tipo:'error',texto:da.innerText.trim(),fuente:'generic'});" +
            "var body=(document.body.innerText||'').toLowerCase();" +
            "return JSON.stringify({tipo:'desconocido',texto:'',fuente:'ninguna',hayBotonCompra:body.indexOf('confirmar la compra')>=0});");

    static boolean contiene(String texto, String... claves) {
        for (String k : claves) if (texto.contains(k)) return true;
        return false;
    }

    /** Un intento de reserva sobre la sesión abierta. Igual que _un_intento del .py. */
    String intento(Tarea t) {
        try {
            String dataDay = t.dataDay();
            if (!esperar(CAL_LISTO, 4000)) {
                log("   🔁 Recargando la página de clases...");
                ui.post(() -> web.reload());
                dormir(1500);
                esperarInactiva(10000);
                if (!esperar(CAL_LISTO, 8000)) {
                    log("   ⚠️ No aparece el calendario (¿sesión caducada?)");
                    return "error";
                }
            }

            // Forzar datos frescos: si ya estamos en el día, pasar por el anterior
            if (dataDay.equals(diaActivo())) seleccionarDia(t.diaPrevio());

            if (!seleccionarDia(dataDay)) {
                log("   ⚠️ No se pudo seleccionar el día " + dataDay);
                return "error";
            }
            if (!esperar(hayTexto(t.clase), 10000)) {
                log("   ⚠️ '" + t.clase + "' no aparece el " + dataDay);
                return "error";
            }

            JSONObject info = new JSONObject(jsTexto(jsEstadoClase(t.clase, t.hora)));
            if (!info.optBoolean("encontrado")) {
                log("   ⚠️ No se encontró " + t.clase + " a las " + t.hora);
                return "error";
            }
            log("   📊 Aforo: " + info.optString("aforo", "?"));
            if (info.optBoolean("lleno")) {
                log("   🔴 Clase llena");
                return "llena";
            }

            log("   👆 Pulsando " + t.hora + "...");
            if (!jsBool(jsClicClase(t.clase, t.hora))) return "error";
            esperarInactiva(12000);
            dormir(1500);

            // Confirmar la compra
            boolean confirmado = false;
            for (String n : new String[]{"Confirmar la compra", "Confirmar compra", "Confirmar"}) {
                if (clicBoton(n)) {
                    log("   ✅ Pulsando '" + n + "'...");
                    confirmado = true;
                    break;
                }
            }
            if (!confirmado && clicTexto("Confirmar la compra")) {
                log("   ✅ Pulsando 'Confirmar la compra' (por texto)...");
                confirmado = true;
            }
            if (!confirmado) {
                for (String n : new String[]{"Reservar", "Aceptar", "Comprar", "Finalizar"}) {
                    if (clicBoton(n)) {
                        log("   ✅ Pulsando '" + n + "'...");
                        confirmado = true;
                        break;
                    }
                }
            }
            if (!confirmado) {
                log("   ⚠️ No se encontró el botón 'Confirmar la compra'");
                return "error";
            }

            log("   ⏳ Esperando confirmación de la web...");
            esperarInactiva(12000);
            dormir(2000);

            JSONObject res = new JSONObject(jsTexto(JS_RESULTADO));
            String texto = res.optString("texto", "").trim();
            String bajo = texto.toLowerCase();
            if (!texto.isEmpty()) log("   📨 La web dice: \"" + texto + "\"");

            String tipo = res.optString("tipo");
            if (tipo.equals("ok") || contiene(bajo, "realizada", "realizado", "correctamente", "confirmada",
                    "confirmado", "compra correcta", "reserva efectuada", "se ha registrado", "gracias")) {
                return "ok";
            }
            if (tipo.equals("error")) {
                if (contiene(bajo, "más de 1", "no se permiten", "ya tiene", "ya has", "una reserva", "ya existe"))
                    return "ya_reservada";
                if (contiene(bajo, "completo", "lleno", "no hay plazas", "sin plazas", "aforo", "no quedan"))
                    return "llena";
                log("   🔴 Error de la web (ver mensaje arriba)");
                return "error";
            }
            if (res.optString("fuente").equals("ninguna") && !res.optBoolean("hayBotonCompra", true)) {
                log("   ✅ El carrito se procesó correctamente");
                return "ok";
            }
            log("   ⚠️ No apareció una confirmación clara");
            return "error";
        } catch (Detenido d) {
            throw d;
        } catch (Exception e) {
            log("   ❌ Error: " + e.getMessage());
            return "error";
        }
    }
}
